package raibagkar.parasmusic;

import android.app.Activity;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.MediaController;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends Activity {
    ListView lv, lv1;
    MediaPlayer mMediaPlayer = new MediaPlayer();
    SeekBar seek_bar;
    String[] items;
    TextView tv1, tv2;
    private String[] mMusicList;
    Handler seekHandler = new Handler();
    String[] items1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv = (ListView) findViewById(R.id.lvPlaylist);
        seek_bar = (SeekBar) findViewById(R.id.seekBar);
        tv1 = (TextView) findViewById(R.id.tvCurrent);
        tv2 = (TextView) findViewById(R.id.tvDuration);
        seek_bar.setMax(mMediaPlayer.getDuration());
        //-------------------------------------------------------------------

        lv1 = new ListView(getApplication());
        ArrayList<File> mySongs = findSongs(Environment.getExternalStorageDirectory());

        items1 = new String[mySongs.size()];
        for (int i = 0; i < mySongs.size(); i++) {
            //toast(mySongs.get(i).getName().toString());
            items1[i] = mySongs.get(i).getAbsolutePath().toString();

        }


        //---------------------------------------------------------------------
        //ArrayList<File> mySongs = findSongs(Environment.getExternalStorageDirectory());

        items = new String[mySongs.size()];
        for (int i = 0; i < mySongs.size(); i++) {
            //toast(mySongs.get(i).getName().toString());
            items[i] = mySongs.get(i).getName().toString().replace(".mp3", "");

        }

        ArrayAdapter<String> adp = new ArrayAdapter<String>(getApplicationContext(), R.layout.song_layout, R.id.tv1, items);//<---------------------
        lv.setAdapter(adp);


//--------------------------------

        // ListView mListView = (ListView) findViewById(R.id.listView);
        //    mMusicList = getMusic();
        //  ArrayAdapter<String> mAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, mMusicList);
        //lv.setAdapter(mAdapter);


        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                try {
          //          toast("Item ClickListner");
                    playSong(items1[arg2]);
                      toast(items1[arg2].toString());
                } catch (IllegalArgumentException e) {
                    e.printStackTrace();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });


    }

    ArrayList<File> findSongs(File root) {
        ArrayList<File> al = new ArrayList<File>();
        File[] files = root.listFiles();
        for (File singleFile : files) {
            if (singleFile.isDirectory() && !singleFile.isHidden()) {
                al.addAll(findSongs(singleFile));
            } else {
                if (singleFile.getName().endsWith(".mp3")) {
                    al.add(singleFile);
                }
            }
        }
        return al;
    }

    public void toast(String text) {
        Toast.makeText(getApplicationContext(), text, Toast.LENGTH_LONG).show();
    }


    private String[] getMusic() {
        final Cursor mCursor = managedQuery(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, new String[]
                {MediaStore.Audio.Media.DISPLAY_NAME}, null, null, "LOWER(" + MediaStore.Audio.Media.TITLE + ") ASC");
        int count = mCursor.getCount();
        String[] songs = new String[count];
        int i = 0;
        if (mCursor.moveToFirst()) {
            do {
                songs[i] = mCursor.getString(0);
                i++;
            } while (mCursor.moveToNext());
        }
        mCursor.close();
        return songs;
    }

/*    private Runnable run = new Runnable() {
        @Override
        public void run() {
            seek_bar.setProgress(mMediaPlayer.getCurrentPosition());
            seekHandler.postDelayed(run, 1000);
        }
    };*/

    private void playSong(String path) throws IllegalArgumentException, IllegalStateException, IOException {
        //tv1.setText(mMediaPlayer.getCurrentPosition());
        //tv2.setText(mMediaPlayer.getDuration());
        String extStorageDirectory = Environment.getExternalStorageDirectory().toString();
        // path = extStorageDirectory + File.separator + path;

        FileInputStream fileInputStream = new FileInputStream(path);
        mMediaPlayer.reset();
//        mMediaPlayer.setDataSource(fileInputStream.getFD());
        mMediaPlayer.setDataSource(path);


        if (mMediaPlayer.isPlaying()) {
            mMediaPlayer.pause();
            fileInputStream.close();
            // toast("stopping the  play");
        }

        // toast("on the way to play ");
        mMediaPlayer.prepare();//------write after close
        mMediaPlayer.start();
       // toast("overtook the play");


    }


    public void stop(View view) {
        mMediaPlayer.stop();
    }

    public void pause(View view) {
        mMediaPlayer.pause();
    }

    public void play(View view) {
        mMediaPlayer.start();
    }
}

/* ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- */

